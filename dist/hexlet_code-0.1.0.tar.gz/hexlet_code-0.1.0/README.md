### Hexlet tests and linter status:
[![Actions Status](https://github.com/gordienkoas/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/gordienkoas/python-project-49/actions)

<a href="https://codeclimate.com/github/gordienkoas/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8726b1ed6c0953930392/maintainability" /></a>

INSTALLATION:

Install using pip:

pip install git+https://github.com/gordienkoas/python-project-49.git

INSTRUCTIONS:

This is a five math games:

Calculator
To win this games you have to solve three math tasks

To start the game run brain-calc

### asciinema brain-calc
https://asciinema.org/a/X9Ej4hL32CFlLfYCYZ2uYMxvR

Even numbers
To win this game you have to give an answer is given number even or not

To start the game run brain-even

### asciinema brain-even

https://asciinema.org/a/NxJ7cy5pj7ADZicDpRe1zox9e
  


To win this game you have to find a GCD of three pairs of numbers

To start the game run brain-gcd

### asciinema brain-gcd

https://asciinema.org/a/vXDJjkVmAtgXIvruPdxjZogEK