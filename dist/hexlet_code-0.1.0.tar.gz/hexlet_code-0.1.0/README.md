### Hexlet tests and linter status:
[![Actions Status](https://github.com/gordienkoas/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/gordienkoas/python-project-49/actions)

<a href="https://codeclimate.com/github/gordienkoas/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8726b1ed6c0953930392/maintainability" /></a>
